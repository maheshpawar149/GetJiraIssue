This extension is the implementation of Python Database API Specification v2.0
The extension supports DB2 (LUW, zOS, i5) and IDS (Informix Dynamic Server)

